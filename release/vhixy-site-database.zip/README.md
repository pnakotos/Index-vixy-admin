# Base de Datos Vixy Admin (MySQL / phpMyAdmin)

Archivos SQL listos para importar en phpMyAdmin u otro gestor MySQL/MariaDB.

## Archivos

- `01_schema.sql` — Estructura vacía de la base.
- `03_remove_demo_records.sql` — Limpieza de registros demo heredados.
- `04_create_vixyman_admin.sql` — Crea el superusuario inicial `vixyman@vhixy.site`.
- `05_reset_vixyman_password.sql` — Restablece su clave temporal si el login devuelve 401.


## Cómo importar en phpMyAdmin

1. En cPanel abre **Bases de datos MySQL** y crea una base con el prefijo que asigna tu hosting, por ejemplo `cpses_vhav72uuuz_vixy`.
2. Asígnale el usuario MySQL `cpses_vhav72uuuz` con todos los privilegios.
3. Entra a phpMyAdmin y selecciona esa base en el panel izquierdo.
4. Ve a **Importar**, selecciona `01_schema.sql` y pulsa **Continuar/Ir**.
5. La base queda deliberadamente sin perfiles, pagos, viajes, logs ni usuarios ficticios. Asegúrate de crear la base de datos manualmente.
6. Si ya importaste una versión anterior con datos de prueba, ejecuta `03_remove_demo_records.sql` una sola vez.
7. Verificado conceptualmente para MySQL 5.7+/8.0 y MariaDB 10.x; valida la importacion en tu servidor antes de produccion.

Si no tienes SSH, importa `04_create_vixyman_admin.sql` después del esquema. El usuario
será `vixyman@vhixy.site`, la clave temporal será `123456` y el cambio será obligatorio.

## Tablas incluidas

`drivers`, `clients`, `payments`, `emergency_alerts`, `push_notifications`, `reviews`, `audit_logs`, `completed_services`, `backend_users`, `system_config`, `branding_media`, `api_interconnection_config`, `rides`, `ride_dispatch_attempts`, `ride_status_history`, `driver_notifications`.

## Notas de seguridad

