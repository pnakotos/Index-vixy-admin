<?php
require_once __DIR__ . '/includes/bootstrap.php';
Response::requireAdminSession($conn, $_SERVER['REQUEST_METHOD'] === 'GET');

$handler = new CrudHandler(
    $conn,
    'emergency_alerts',
    'id',
    [
        'id', 'type', 'reporter_type', 'reporter_id', 'reporter_name', 'reporter_phone',
        'category', 'vehicle_info', 'plate_number', 'location_name', 'lat', 'lng',
        'status', 'notes', 'resolved_by', 'timestamp',
    ],
    'emg'
);

$handler->handle();
