<?php
header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'name' => 'Vixy Admin API',
    'status' => 'ok',
    'endpoints' => [
        '/api/auth.php?action=login', '/api/auth.php?action=logout', '/api/auth.php?action=me',
        '/api/drivers.php', '/api/clients.php', '/api/payments.php', '/api/emergencies.php',
        '/api/notifications.php', '/api/reviews.php', '/api/audit_logs.php',
        '/api/completed_services.php', '/api/users.php', '/api/system_config.php',
        '/api/branding_media.php', '/api/api_config.php', '/api/rides.php', '/api/version.php',
    ],
]);
